GST Khata React App
====================
React POS application with:
- Sales & Purchase
- Role-based access
- Offline-first logic
- WhatsApp invoice sharing

Run:
npm install
npm run dev
