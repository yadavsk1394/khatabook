import { useState } from "react";
import { useAuth } from "./context/AuthContext";
import Login from "./components/Login";
import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import Sales from "./components/Sales";
import Purchase from "./components/Purchase";
import History from "./components/History";

export default function AppMain() {
  const { user } = useAuth();
  const [page, setPage] = useState("dash");

  if (!user) return <Login />;

  const render = () => {
    switch(page) {
      case "sale": return <Sales />;
      case "purchase": return <Purchase />;
      case "history": return <History />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="app-container">
      <Sidebar page={page} setPage={setPage} />
      <main className="main-content">{render()}</main>
    </div>
  );
}
