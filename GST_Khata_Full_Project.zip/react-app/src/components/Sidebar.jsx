import { useAuth } from "../context/AuthContext";

export default function Sidebar({ page, setPage }) {
  const { user, logout } = useAuth();
  return (
    <aside>
      <div>GST Khata ({user.role})</div>
      <button onClick={()=>setPage("dash")}>Dashboard</button>
      {user.role !== "VIEWER" && <button onClick={()=>setPage("sale")}>Sales</button>}
      {user.role === "ADMIN" && <button onClick={()=>setPage("purchase")}>Purchase</button>}
      <button onClick={()=>setPage("history")}>History</button>
      <button onClick={logout}>Logout</button>
    </aside>
  );
}
