import { useState } from "react";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const { login } = useAuth();
  const [u, setU] = useState("");
  const [r, setR] = useState("ADMIN");
  return (
    <div>
      <input placeholder="Username" onChange={e=>setU(e.target.value)} />
      <select onChange={e=>setR(e.target.value)}>
        <option>ADMIN</option>
        <option>CASHIER</option>
        <option>VIEWER</option>
      </select>
      <button onClick={()=>login(u,r)}>Login</button>
    </div>
  );
}
