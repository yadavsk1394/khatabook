import { AuthProvider } from "./context/AuthContext";
import { AppProvider } from "./context/AppContext";
import AppMain from "./AppMain";

export default function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <AppMain />
      </AppProvider>
    </AuthProvider>
  );
}
