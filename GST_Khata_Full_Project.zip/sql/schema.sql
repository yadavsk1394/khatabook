CREATE TABLE Products(
  ProductId INT IDENTITY PRIMARY KEY,
  Name NVARCHAR(100),
  Price DECIMAL(10,2),
  Stock INT
);

CREATE TABLE Transactions(
  TransactionId BIGINT PRIMARY KEY,
  Type VARCHAR(10),
  Total DECIMAL(12,2),
  Date DATETIME
);
