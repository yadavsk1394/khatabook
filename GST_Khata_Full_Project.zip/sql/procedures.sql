CREATE PROCEDURE SaveTransaction
  @TransactionId BIGINT,
  @Type VARCHAR(10),
  @Total DECIMAL(12,2)
AS
BEGIN
  INSERT INTO Transactions VALUES(@TransactionId,@Type,@Total,GETDATE());
END
