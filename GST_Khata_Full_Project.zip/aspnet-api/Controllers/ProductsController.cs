using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/products")]
public class ProductsController : ControllerBase {
  [HttpGet]
  public IActionResult Get() {
    return Ok(new [] { new { Id=1, Name="Sample", Price=100, Stock=10 }});
  }
}
